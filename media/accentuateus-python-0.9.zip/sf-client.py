#!/usr/bin/env python
# -*- coding: utf-8 -*-
# json is part of Python 2.6, not 2.5.  
import httplib
import json
import sys
import re
import os
import getopt
import locale
import socket

# hack to allow piping of output w/o errors
reload(sys)
sys.setdefaultencoding('utf-8')

client_version = '@CLIENTVERSION'
mylocale = 'xx'
# TRANSLATIONS HERE
translations = {'Option --input/-i may only be used with --restore/-r.':{'ga':'Níl --input/-i ceadaithe ach amháin in éineacht le --restore/-r.','af':'Die keuse --input/-i mag net saam met --restore/-r gebruik word.','ht':'Opsyon --input/i dwe sèlman itilize avèk --restore/-r','ia':'Option --input/i pote solmente esser usate con --restore/-r.',},'The add-on was unable to connect with the server.  Please try again later.':{'ga':'Ní raibh an breiseán in ann dul i dteagmháil leis an bhfreastalaí.  Bain triail eile as ar ball.','af':'Die byvoeging kon nie koppel aan die bediener nie.  Probeer gerus weer later.','ht':'Modil la pa rive konekte ak sevè a. Eseye ankò yon lòt lè.','ia':'Le add-on esseva incapace a connectar con le servitor. Pro favor tu prova plus tarde. ',},'Long versions of the command-line switches are available also:':{'ga':'Is féidir leaganacha fada de na roghanna ar líne na n-orduithe a úsáid freisin:','af':'Lang weergawes van die opdryglyn-keuses is ook beskikbaar:','ht':'Yon vèsyon long de switch liy kòman lan disponib tou:','ia':'Versione plus longe del dispositivos de linea de commando es anque disponibile:',},'or     %1$S -r -l XX -i ASCII-TEXT':{'ga':'nó     %1$S -r -l XX -i \'TÉACS-LE-hATHCHÓIRIÚ\'','af':'of     %1$S -r -l XX -i ASCII-TEKS','ht':'osinon %1$S -r -l XX -i ASCII-TEXT','ia':'o   %1$S -r -l XX -i TEXTO-ASCII',},'You must specify exactly one of -f or -r.':{'ga':'Caithfidh tú ceann amháin de -f nó -r a roghnú.','af':'Spesifiseer presies een van -f of -r.','ht':'Ou dwe di ekzateman youn nan -f osinon -r','ia':'Tu debe specidicar exactemente uno de -f o -r.',},'Didn\'t understand the response from the server':{'ga':'Níor tuigeadh an freagra ón bhfreastalaí','af':'Het nie die bediener se antwoord verstaan nie','ht':'Pa konprann repons de sèvè a','ia':'Il non comprende le responsa ex le servitor',},'Usage: %1$S -r -l XX [FILES-TO-RESTORE]':{'ga':'Úsáid: %1$S -r -l XX [COMHAID-LE-hATHCHÓIRIÚ]','af':'Gebruik: %1$S -r -l XX [LÊERS-OM-TE-KORRIGEER]','ht':'Izaj: %1$S -r -l XX [FILES-TO-RESTORE]','ia':'Uso: %1$S -r -l XX [FILES-DE-RESTABILIR]',},'You must specify a language with -l or --lang.':{'ga':'Caithfidh tú teanga a shonrú le -l nó --lang.','af':'Spesifiseer \'n taal met -l of --lang.','ht':'Ou dwe chwazi yon lang avèk -l osinon --lang','ia':'Tu debe specificar un linguage con -l o --lang',},'Accentuate.us: Feedback Submitted':{'ga':'Accentuate.us: Aiseolas Seolta','af':'Accentuate.us: Terugvoer ingedien','ht':'Accentuate.us: Reyaksyon an soumèt','ia':'Accentuate.us: Feedback submittite',},'or     %1$S --list (show all available languages)':{'ga':'nó     %1$S --list (taispeáin na teangacha atá ar fáil)','af':'of     %1$S --list (wys alle beskikbare tale)','ht':'osinon %1$S --list (montre tout lang ki disponib yo)','ia':'o   %1$S --list (monstrar omne linguage disponibile)',},'or     %1$S -f -l XX [CORRECT-FILES]':{'ga':'nó     %1$S -f -l XX [COMHAID-CHEARTA]','af':'of     %1$S -f -l XX [KORREKTE-LÊERS]','ht':'osinon %1$S -f -l XX [CORRECT-FILES]','ia':'o     %1$S -f -l XX [FILES-CORRIGITE]',},'or     %1$S --help (display this help)':{'ga':'nó     %1$S --help (taispeáin an chabhair seo)','af':'of     %1$S --help (vertoon dié hulp)','ht':'osinon %1$S --help (afiche èd la)','ia':'o    %1$S --help (monstrar iste adjuta)',},}
supported = {'ne':1,'tr':1,'da':1,'gl':1,'ru':1,'ia':1,'nb':1,'ro':1,'ku':1,'nso':1,'vi':1,'az':1,'tn':1,'ta':1,'lb':1,'rw':1,'nr':1,'es-AR':1,'ml':1,'ts':1,'cy':1,'st':1,'ko':1,'cs':1,'uz':1,'ps':1,'zh-HK':1,'en-IE':1,'km':1,'af':1,'ht':1,'en-GB':1,'is':1,'bs':1,'hy':1,'ga':1,'ms':1,'hsb':1,'eu':1,'ka':1,'wa':1,'oc':1,'bg':1,'gu':1,'sv':1,'es-MX':1,'it':1,'hu':1,'fa':1,'sq':1,'ca':1,'pl':1,'bn-IN':1,'se':1,'sk':1,'nds':1,'ve':1,'en-ZA':1,'pt':1,'hi':1,'uk':1,'es':1,'csb':1,'lv':1,'ast':1,'zh-CN':1,'fr':1,'ss':1,'or':1,'id':1,'xh':1,'sr':1,'th':1,'si':1,'et':1,'es-CL':1,'mk':1,'fi':1,'lt':1,'hr':1,'mai':1,'ta-LK':1,'de':1,'be':1,'zh-TW':1,'zu':1,'en-US':1,'pa':1,'sl':1,'nn':1,'am':1,'ja':1,'bn':1,'tg':1,'hne':1,'mr':1,'pt-BR':1,'rm':1,'ilo':1,'kn':1,'he':1,'te':1,'fy':1,'eo':1,'nl':1,'ar':1,'crh':1,'mn':1,'gd':1,'as':1,'el':1,'kk':1,}

def kprint(s):
	print s.encode('utf-8')

def kprint2(s):
	print s.encode('utf-8'),

def libc_locale_to_rfc4646(loc):
	if loc == 'POSIX' or loc == 'C':
		return 'xx'
	at_index = loc.find('@')
	at = ''
	if at_index != -1:
		at = loc[at_index+1:]
		loc = loc[:at_index]
		if at == 'saaho':
			return 'ssy-ER'
		if at == 'valencia':
			return 'ca-ES-valencia'
		scripts = {'latin' : 'Latn', 'cyrillic' : 'Cyrl', 'devanagari' : 'Deva'}
		if at in scripts:
			at = scripts[at]
	dot_index = loc.find('.')
	if dot_index != -1:
		loc = loc[:dot_index]
	if at != '':
		us_index = loc.find('_')
		if us_index != -1:
			loc = loc.replace('_','-'+at+'-')
		else:
			loc = loc+'-'+at
	loc = loc.replace('_','-')
	return loc

# sets global "mylocale"
def determine_locale():
	global mylocale
	try:
		mylocale = locale.setlocale(locale.LC_MESSAGES, '');
	except locale.Error:
		# proceed silently
		mylocale = 'xx'
	mylocale = libc_locale_to_rfc4646(mylocale)
	if mylocale not in supported:
		uscr = mylocale.find('-')
		if uscr != -1:
			mylocale = mylocale[:uscr]
		if mylocale == 'zh':
			mylocale = 'zh-CN'

# args is a tuple of all arguments past the first
def gettexter(msg, *args):
	global translations
	if msg in translations and mylocale in translations[msg]:
		msg = translations[msg][mylocale]
	if len(args) > 0:
		msg = msg.replace('%1$S', args[0])
	return msg

def packnsend(json_dict, hostname):
	jsonstr = json.dumps(json_dict)
	host = hostname+':8080'
	try:
		req = httplib.HTTPConnection(host, timeout=15)
		req.putrequest('POST', '/')
		p = re.compile(' .*',re.DOTALL)
		python_version = p.sub('',sys.version)
		req.putheader("User-Agent", 'Accentuate.us/'+client_version+' httplib-python/'+python_version)
		req.putheader("Host", host)
		req.putheader("Content-Type", 'application/json; charset=UTF-8')
		req.putheader("Content-Length", str(len(jsonstr)))
		req.endheaders()
		req.send(jsonstr)
	except socket.error:
		kprint(gettexter('The add-on was unable to connect with the server.  Please try again later.'))
		return ''
	
	r1 = req.getresponse()
	if r1.status != 200:
		# kprint(r1.reason) for debugging
		kprint(gettexter("Didn't understand the response from the server"))
		return ''
	try:
		resp_hash = json.loads(r1.read())
	except ValueError:
		kprint(gettexter("Didn't understand the response from the server"))
		return ''
	ans = ''
	if 'text' in resp_hash.keys():
		ans = resp_hash['text']
	return ans
	

def send_feedback(text, langarg):
	return packnsend({'lang' : langarg, 'text' : text, 'call' : 'charlifter.feedback', 'locale' : mylocale}, 'api.accentuate.us')

def get_languages():
	return packnsend({'version' : 0, 'locale' : mylocale, 'call' : 'charlifter.langs'}, 'api.accentuate.us')

def restore(text, langarg):
	return packnsend({'lang' : langarg, 'text' : text, 'call' : 'charlifter.lift', 'locale' : mylocale}, langarg+'.api.accentuate.us')


# one arg is list of files from command line after opts parsed
# ok to just read in as byte streams for now; if we eventually want UTF-8,
# can do sys.stdin = codecs.getreader("utf-8")(sys.stdin) 
# and for files, file = codecs.open('utf8_input', encoding='utf-8') 
def restore_files(args, langarg):
	if len(args) > 0:	
		for filenm in args:
			if filenm == '-':
				kprint2(restore(sys.stdin.read(), langarg))
			else:
				kprint2(restore(file(filenm).read(), langarg))
	else:
		kprint2(restore(sys.stdin.read(), langarg))

# one arg is list of files from command line after opts parsed
def do_feedback(args, langarg):
	if len(args) > 0:	
		for filenm in args:
			if filenm == '-':
				send_feedback(sys.stdin.read(), langarg)
			else:
				send_feedback(file(filenm).read(), langarg)
	else:
		send_feedback(sys.stdin.read(), langarg)

def usage():
	kprint(gettexter('Usage: %1$S -r -l XX [FILES-TO-RESTORE]', 'sf-client.py'))
	kprint(gettexter('or     %1$S -r -l XX -i ASCII-TEXT', 'sf-client.py'))
	kprint(gettexter('or     %1$S -f -l XX [CORRECT-FILES]', 'sf-client.py'))
	kprint(gettexter('or     %1$S --list (show all available languages)', 'sf-client.py'))
	kprint(gettexter('or     %1$S --help (display this help)', 'sf-client.py'))
	kprint(gettexter('Long versions of the command-line switches are available also:'))
	kprint('-r/--restore, -f/--feedback, -l/--lang, -i/--input')

def main():
	determine_locale()
	feedback_p = False;
	inputgiven_p = False;
	restore_p = False;
	list_langs_p = False;
	langarg = 'xx'
	inputtext = ''
	try:
		opts, args = getopt.gnu_getopt(sys.argv[1:], "fi:l:rs:", ['feedback', 'help', 'input=', 'lang=', 'list', 'restore']) 
	except getopt.GetoptError, err:
		kprint(str(err))
		usage()
		sys.exit(2)
	for o, a in opts:   # o=option, a=arg
		if o == "--list":
			list_langs_p = True
		elif o == "--help":
			usage()
			sys.exit(0)
		elif o in ("-f", "--feedback"):
			feedback_p = True
		elif o in ("-i", "--input"):
			inputtext = a
			inputgiven_p = True
		elif o in ("-l", "--lang"):
			langarg = a
		elif o in ("-r", "--restore"):
			restore_p = True
		else: # unrecognized option
			usage()
			sys.exit(0)
	if list_langs_p:
		kprint2(get_languages())
		sys.exit(0)
	if (feedback_p and restore_p) or (not restore_p and not feedback_p):
		usage()
		print
		kprint(gettexter("You must specify exactly one of -f or -r."))
	elif langarg == 'xx':
		usage()
		print
		kprint(gettexter("You must specify a language with -l or --lang."))
	elif feedback_p and inputgiven_p: 
		usage()
		print
		kprint(gettexter("Option --input/-i may only be used with --restore/-r."))
	elif restore_p:
		if inputgiven_p:
			kprint2(restore(inputtext, langarg))
		else:
			restore_files(args, langarg)
	elif feedback_p:
		do_feedback(args, langarg)
			
		

if __name__ == "__main__":
	main()
