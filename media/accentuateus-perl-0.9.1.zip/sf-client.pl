#!/usr/bin/perl
# This file is part of Charlifter.
# Copyright 2008-2009 Kevin P. Scannell <kscanne at gmail dot com>
# 
#     Charlifter is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
# 
#     Charlifter is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
# 
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <http://www.gnu.org/licenses/>.

require 5.004;
use strict;
use warnings;
use utf8;
use POSIX qw(locale_h);
use open qw(:std :utf8);
use Getopt::Long;
use LWP::UserAgent;
use HTTP::Request;
use JSON;
use Encode qw(decode);

my $client_version = '0.9.1';
# TRANSLATIONS HERE
my $translationsref = {
                     'Option --input/-i may only be used with --restore/-r.' => {
                                                                                'ga' => "N\x{ed}l --input/-i ceadaithe ach amh\x{e1}in in \x{e9}ineacht le --restore/-r.",
                                                                                'af' => 'Die keuse --input/-i mag net saam met --restore/-r gebruik word.',
                                                                                'ht' => "Opsyon --input/i dwe s\x{e8}lman itilize av\x{e8}k --restore/-r",
                                                                                'ia' => 'Option --input/i pote solmente esser usate con --restore/-r.'
                                                                              },
                     'The add-on was unable to connect with the server.  Please try again later.' => {
                                                                                                     'ga' => "N\x{ed} raibh an breise\x{e1}n in ann dul i dteagmh\x{e1}il leis an bhfreastala\x{ed}.  Bain triail eile as ar ball.",
                                                                                                     'af' => 'Die byvoeging kon nie koppel aan die bediener nie.  Probeer gerus weer later.',
                                                                                                     'ht' => "Modil la pa rive konekte ak sev\x{e8} a. Eseye ank\x{f2} yon l\x{f2}t l\x{e8}.",
                                                                                                     'ia' => 'Le add-on esseva incapace a connectar con le servitor. Pro favor tu prova plus tarde. '
                                                                                                   },
                     'Long versions of the command-line switches are available also:' => {
                                                                                         'ga' => "Is f\x{e9}idir leaganacha fada de na roghanna ar l\x{ed}ne na n-orduithe a \x{fa}s\x{e1}id freisin:",
                                                                                         'af' => 'Lang weergawes van die opdryglyn-keuses is ook beskikbaar:',
                                                                                         'ht' => "Yon v\x{e8}syon long de switch liy k\x{f2}man lan disponib tou:",
                                                                                         'ia' => 'Versione plus longe del dispositivos de linea de commando es anque disponibile:'
                                                                                       },
                     'or     %1$S -r -l XX -i ASCII-TEXT' => {
                                                             'ga' => "n\x{f3}     %1\$S -r -l XX -i 'T\x{c9}ACS-LE-hATHCH\x{d3}IRI\x{da}'",
                                                             'af' => 'of     %1$S -r -l XX -i ASCII-TEKS',
                                                             'ht' => 'osinon %1$S -r -l XX -i ASCII-TEXT',
                                                             'ia' => 'o   %1$S -r -l XX -i TEXTO-ASCII'
                                                           },
                     'You must specify exactly one of -f or -r.' => {
                                                                    'ga' => "Caithfidh t\x{fa} ceann amh\x{e1}in de -f n\x{f3} -r a roghn\x{fa}.",
                                                                    'af' => 'Spesifiseer presies een van -f of -r.',
                                                                    'ht' => 'Ou dwe di ekzateman youn nan -f osinon -r',
                                                                    'ia' => 'Tu debe specidicar exactemente uno de -f o -r.'
                                                                  },
                     'Didn\'t understand the response from the server' => {
                                                                         'ga' => "N\x{ed}or tuigeadh an freagra \x{f3}n bhfreastala\x{ed}",
                                                                         'af' => 'Het nie die bediener se antwoord verstaan nie',
                                                                         'ht' => "Pa konprann repons de s\x{e8}v\x{e8} a",
                                                                         'ia' => 'Il non comprende le responsa ex le servitor'
                                                                       },
                     'Usage: %1$S -r -l XX [FILES-TO-RESTORE]' => {
                                                                  'ga' => "\x{da}s\x{e1}id: %1\$S -r -l XX [COMHAID-LE-hATHCH\x{d3}IRI\x{da}]",
                                                                  'af' => "Gebruik: %1\$S -r -l XX [L\x{ca}ERS-OM-TE-KORRIGEER]",
                                                                  'ht' => 'Izaj: %1$S -r -l XX [FILES-TO-RESTORE]',
                                                                  'ia' => 'Uso: %1$S -r -l XX [FILES-DE-RESTABILIR]'
                                                                },
                     'You must specify a language with -l or --lang.' => {
                                                                         'ga' => "Caithfidh t\x{fa} teanga a shonr\x{fa} le -l n\x{f3} --lang.",
                                                                         'af' => 'Spesifiseer \'n taal met -l of --lang.',
                                                                         'ht' => "Ou dwe chwazi yon lang av\x{e8}k -l osinon --lang",
                                                                         'ia' => 'Tu debe specificar un linguage con -l o --lang'
                                                                       },
                     'Accentuate.us: Feedback Submitted' => {
                                                            'ga' => 'Accentuate.us: Aiseolas Seolta',
                                                            'af' => 'Accentuate.us: Terugvoer ingedien',
                                                            'ht' => "Accentuate.us: Reyaksyon an soum\x{e8}t",
                                                            'ia' => 'Accentuate.us: Feedback submittite'
                                                          },
                     'or     %1$S --list (show all available languages)' => {
                                                                            'ga' => "n\x{f3}     %1\$S --list (taispe\x{e1}in na teangacha at\x{e1} ar f\x{e1}il)",
                                                                            'af' => 'of     %1$S --list (wys alle beskikbare tale)',
                                                                            'ht' => 'osinon %1$S --list (montre tout lang ki disponib yo)',
                                                                            'ia' => 'o   %1$S --list (monstrar omne linguage disponibile)'
                                                                          },
                     'or     %1$S -f -l XX [CORRECT-FILES]' => {
                                                               'ga' => "n\x{f3}     %1\$S -f -l XX [COMHAID-CHEARTA]",
                                                               'af' => "of     %1\$S -f -l XX [KORREKTE-L\x{ca}ERS]",
                                                               'ht' => 'osinon %1$S -f -l XX [CORRECT-FILES]',
                                                               'ia' => 'o     %1$S -f -l XX [FILES-CORRIGITE]'
                                                             },
                     'or     %1$S --help (display this help)' => {
                                                                 'ga' => "n\x{f3}     %1\$S --help (taispe\x{e1}in an chabhair seo)",
                                                                 'af' => "of     %1\$S --help (vertoon di\x{e9} hulp)",
                                                                 'ht' => "osinon %1\$S --help (afiche \x{e8}d la)",
                                                                 'ia' => 'o    %1$S --help (monstrar iste adjuta)'
                                                               }
                   };
my $supportedref = {
                  'ne' => 1,
                  'tr' => 1,
                  'da' => 1,
                  'gl' => 1,
                  'ru' => 1,
                  'ia' => 1,
                  'nb' => 1,
                  'ro' => 1,
                  'ku' => 1,
                  'nso' => 1,
                  'vi' => 1,
                  'az' => 1,
                  'tn' => 1,
                  'ta' => 1,
                  'lb' => 1,
                  'rw' => 1,
                  'nr' => 1,
                  'es-AR' => 1,
                  'ml' => 1,
                  'ts' => 1,
                  'cy' => 1,
                  'st' => 1,
                  'ko' => 1,
                  'cs' => 1,
                  'uz' => 1,
                  'ps' => 1,
                  'zh-HK' => 1,
                  'en-IE' => 1,
                  'km' => 1,
                  'af' => 1,
                  'ht' => 1,
                  'en-GB' => 1,
                  'is' => 1,
                  'bs' => 1,
                  'hy' => 1,
                  'ga' => 1,
                  'ms' => 1,
                  'hsb' => 1,
                  'eu' => 1,
                  'ka' => 1,
                  'wa' => 1,
                  'oc' => 1,
                  'bg' => 1,
                  'gu' => 1,
                  'sv' => 1,
                  'es-MX' => 1,
                  'it' => 1,
                  'hu' => 1,
                  'fa' => 1,
                  'sq' => 1,
                  'ca' => 1,
                  'pl' => 1,
                  'bn-IN' => 1,
                  'se' => 1,
                  'sk' => 1,
                  'nds' => 1,
                  've' => 1,
                  'en-ZA' => 1,
                  'pt' => 1,
                  'hi' => 1,
                  'uk' => 1,
                  'es' => 1,
                  'csb' => 1,
                  'lv' => 1,
                  'ast' => 1,
                  'zh-CN' => 1,
                  'fr' => 1,
                  'ss' => 1,
                  'or' => 1,
                  'id' => 1,
                  'xh' => 1,
                  'sr' => 1,
                  'th' => 1,
                  'si' => 1,
                  'et' => 1,
                  'es-CL' => 1,
                  'mk' => 1,
                  'fi' => 1,
                  'lt' => 1,
                  'hr' => 1,
                  'mai' => 1,
                  'ta-LK' => 1,
                  'de' => 1,
                  'be' => 1,
                  'zh-TW' => 1,
                  'zu' => 1,
                  'en-US' => 1,
                  'pa' => 1,
                  'sl' => 1,
                  'nn' => 1,
                  'am' => 1,
                  'ja' => 1,
                  'bn' => 1,
                  'tg' => 1,
                  'hne' => 1,
                  'mr' => 1,
                  'pt-BR' => 1,
                  'rm' => 1,
                  'ilo' => 1,
                  'kn' => 1,
                  'he' => 1,
                  'te' => 1,
                  'fy' => 1,
                  'eo' => 1,
                  'nl' => 1,
                  'ar' => 1,
                  'crh' => 1,
                  'mn' => 1,
                  'gd' => 1,
                  'as' => 1,
                  'el' => 1,
                  'kk' => 1
                };

# ISO 15924
my %scripts = (
	'latin' => 'Latn',
	'cyrillic' => 'Cyrl',
	'devanagari' => 'Deva',
);

# one arg is locale name like "ga_IE.utf8" or "ar_KW" or "aa_ER@saaho", etc.
# returns an rfc4646 language identifier as close to equivalent as possible
# undef for "C", "POSIX" etc.
sub libc_locale_to_rfc4646 {
	(my $loc) = @_;
	return undef if ($loc eq 'C' or $loc eq 'POSIX'); # others?
	$loc =~ s/@(.*)$//;
	my $at = '';
	$at = $1 if defined $1;
	$loc =~ /^/;
	return 'ssy-ER' if ($at eq 'saaho');
	return "ca-ES-valencia" if ($at eq 'valencia');
	if (exists($scripts{$at})) {
		$at = $scripts{$at};
	}
	else {
		# ignore all other @'s: euro, abegede (collation), iqtelif, cjknarrow
		$at = '';
	}
	$loc =~ s/\..*$//;  # ignore .utf8, .iso88591, etc.
	if ($at ne '') {
		$loc =~ s/^([a-z]{2,3})/$1-$at/;
	}
	$loc =~ s/_/-/g;
	return $loc;
}

my $loc = setlocale(LC_MESSAGES, "");  # get locale from env. variables; ASCII so prob. no need to decode to perl string
if (defined $loc) {
	$loc = libc_locale_to_rfc4646($loc);
	$loc = 'xx' unless defined $loc;  # => en-US messages but native lang names; need to specify "en" or "en-US" to get English lang names
	unless (exists($supportedref->{$loc})) {
		$loc =~ s/-.*$//;
		$loc = 'zh-CN' if ($loc eq 'zh');
	}
}
else {
	# e.g. if locale in env variable is not defined on system
	$loc = 'xx'  # => en-US messages but native lang names
}


# one arg string to localize; language "$loc" is set via locale above 
sub gettexter {
    (my $text, my @vars) = @_;
	my $ans = $text;
	$ans = $translationsref->{$text}{$loc} if exists($translationsref->{$text}{$loc});
	$ans =~ s/\%1\$S/$vars[0]/g;
    return $ans;
}


my $s1 = gettexter('Usage: %1$S -r -l XX [FILES-TO-RESTORE]', 'sf-client.pl');
my $s2 = gettexter('or     %1$S -r -l XX -i ASCII-TEXT', 'sf-client.pl');
my $s3 = gettexter('or     %1$S -f -l XX [CORRECT-FILES]', 'sf-client.pl');
my $s4 = gettexter('or     %1$S --list (show all available languages)', 'sf-client.pl');
my $s5 = gettexter('or     %1$S --help (display this help)', 'sf-client.pl');
my $s6 = gettexter("Long versions of the command-line switches are available also:");
my $s7 = "-r/--restore, -f/--feedback, -l/--lang, -i/--input";   # don't localize!
my $usage = "$s1\n$s2\n$s3\n$s4\n$s5\n$s6\n$s7\n";
binmode STDIN, ":utf8";
binmode STDOUT, ":utf8";
binmode STDERR, ":utf8";

# run modes...
my $restore_arg=0;
my $feedback_arg=0;
my $list_langs_arg=0;

# other command-line arguments
my $read_files_arg=1;  # default is to read <> unless -r, --input are specf'd
my $lang_arg='';
my $input_arg='';

my $ua = LWP::UserAgent->new;
$ua->agent('Accentuate.us/'.$client_version.' '.$ua->_agent);
$ua->timeout(15);  # default is 180

# give this a hashref and a servername (no http, no port), e.g. ga.api.acc.us
sub packnsend {
    (my $href, my $serv) = @_;
    my $tosend = encode_json($href);
    my $r = HTTP::Request->new(POST => 'http://'.$serv.':8080/');
    $r->header('Content-Type' => 'application/json; charset=UTF-8');
    $r->content( $tosend );
    my $response;
    $response = $ua->request($r);
	if ($response->is_success) {  # got a json response (could be an error in it)
	    my $hashref;
		# should always be a 'code' in response
		# but not necessarily a 'text' field (e.g. feedback)
		if (!defined(eval { $hashref = decode_json($response->content) }) or
			!defined($hashref) or ref($hashref) ne 'HASH' or !exists($hashref->{'code'})) {
			print STDERR gettexter("Didn't understand the response from the server")."\n";
		}
		else {
			my $t = '';
			$t = $hashref->{'text'} if (exists($hashref->{'text'}));
			if ($hashref->{'code'} == 400) {
				print STDERR "$t\n";
			}
			else {
   			 	return $t;
			}
		}
	}
	else {
		# timeout, or connection refused usually
	#	print STDERR $response->status_line."\n";
		print STDERR gettexter("The add-on was unable to connect with the server.  Please try again later.")."\n";
	}
	return undef;
}

sub restore {
	(my $text) = @_;
	return packnsend({'lang' => $lang_arg,
					'text' => $text,
					'call' => 'charlifter.lift',
					'locale' => $loc,
					}, $lang_arg.'.api.accentuate.us');
}

# first arg is option name, here "input", second is value
sub handle_input_string {
	shift;
	$input_arg = shift;
	$read_files_arg = 0;
}

# assuming UTF-8 locale for now, can also use I18N::Langinfo
@ARGV = map { decode 'utf-8', $_ } @ARGV;
# see gram.pl - wrap in eval, trap WARN and report errors with gettexter
GetOptions('restore|r' => \$restore_arg,
			'feedback|f' => \$feedback_arg,
			'lang|l=s' => \$lang_arg,
			'input|i=s' => \&handle_input_string,
			'list' => \$list_langs_arg,
			'help' => sub { print $usage; exit 0;},
			);


if ($list_langs_arg) {
	# *will* return code 100... just get text field
	my $ans = packnsend({'version' => 0,  # force send every time, no caching
						'locale' => $loc,
						'call' => 'charlifter.langs',
						}, 'api.accentuate.us');
	print "$ans\n" if defined $ans;
	exit 0;
}

unless ($restore_arg+$feedback_arg == 1) {
	print "$usage\n".gettexter("You must specify exactly one of -f or -r.")."\n";
	exit 1;
}

if ($lang_arg eq '') {
	print "$usage\n".gettexter("You must specify a language with -l or --lang.")."\n";
	exit 1;
}

unless ($read_files_arg or $restore_arg) {
	print "$usage\n".gettexter("Option --input/-i may only be used with --restore/-r.")."\n";
	exit 1;
}

if ($restore_arg) {
	if ($read_files_arg) {
		local $/;
		while (<>) {
			my $ans = restore($_);
			if (defined $ans) {
				print $ans;
			}
			else {
				exit 1;
			}
		}
	}
	else {
		my $ans = restore($input_arg);
		if (defined $ans) {
			print $ans;
		}
		else {
			exit 1;
		}
	}
}
elsif ($feedback_arg) {
	local $/;
	my $ok_p = 1;
	while (<>) {
		$ok_p &= defined(packnsend({'lang' => $lang_arg,
									'text' => $_,
									'call' => 'charlifter.feedback',
									'locale' => $loc,
									}, 'api.accentuate.us'));
	}
	if ($ok_p) {
		print gettexter("Accentuate.us: Feedback Submitted")."\n";
	}
}
else {
#	never gets here
    die $usage;
}

exit 0;
